from setuptools import setup, find_packages
import platform

install_requires = [
    "asgiref==3.8.1",
    "attrs==24.1.0",
    "autobahn==24.4.2",
    "Automat==22.10.0",
    "cffi==1.16.0",
    "channels==4.1.0",
    "channels-redis==4.2.0",
    "constantly==23.10.4",
    "cryptography==43.0.0",
    "daphne==4.1.2",
    "Django==5.0.7",
    "django-cors-headers==4.4.0",
    "djangorestframework==3.15.2",
    "djangorestframework-simplejwt==5.3.1",
    "hyperlink==21.0.0",
    "idna==3.7",
    "incremental==24.7.2",
    "msgpack==1.0.8",
    "pyasn1==0.6.0",
    "pyasn1_modules==0.4.0",
    "pycparser==2.22",
    "PyJWT==2.9.0",
    "pyOpenSSL==24.2.1",
    "redis==5.0.8",
    "service-identity==24.1.0",
    "setuptools==72.1.0",
    "six==1.16.0",
    "sqlparse==0.5.1",
    "Twisted==24.3.0",
    "txaio==23.1.1",
    "typing_extensions==4.12.2",
    "tzdata==2024.1",
    "zope.interface==6.4.post2"
]

if platform.system() == "Windows":
    install_requires.append("twisted-iocpsupport==1.0.4")

setup(
    name="your_project_name",
    version="1.0",
    packages=find_packages(),
    install_requires=install_requires,
)
