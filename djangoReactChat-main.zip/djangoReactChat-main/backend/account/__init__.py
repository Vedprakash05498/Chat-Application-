# account/__init__.py

# default_app_config = 'account.apps.AccountConfig'
